---
layout: default
title: Daftar Modpack
---

# Modpack Survival 🛠️

Berikut mod-mod andalan buat survival:

- [Sodium](https://modrinth.com/mod/sodium)
- [Lithium](https://modrinth.com/mod/lithium)
- [VoxelMap](https://modrinth.com/mod/voxelmap)
- [Shulker Box Tooltip](https://modrinth.com/mod/shulkerboxtooltip)

> Semua mod Fabric, tested 1.20.1 🔥
