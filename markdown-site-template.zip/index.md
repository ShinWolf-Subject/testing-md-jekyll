---
layout: default
title: Halaman Utama
---

# Halo Dunia 🗿

Ini adalah website buatan sendiri pakai **Markdown**!

- Bisa dibuka lewat browser
- Bisa di-edit pakai Acode
- Bisa di-host gratis di GitHub Pages

## Tambahan

Lo bisa tambah gambar, link, atau list dengan gampang:

![Contoh Gambar](https://via.placeholder.com/300x150.png)

[Link ke GitHub](https://github.com)
