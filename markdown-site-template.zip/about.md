---
layout: default
title: Tentang Situs
---

# Tentang Website Ini

Dibuat cuma pakai Markdown + GitHub Pages + Acode doang 🗿

Bisa diakses di HP, ringan, dan gampang di-maintain.
